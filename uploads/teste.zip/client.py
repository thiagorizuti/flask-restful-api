import requests

r = requests.get('http://localhost:5000')
r.text
#r.json()